
export default function Home() {
  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
      height: '100vh',
      fontFamily: 'sans-serif',
      background: '#fff0f0',
      color: '#990000',
      textAlign: 'center',
      padding: '20px'
    }}>
      <h1 style={{ fontSize: '2.5rem' }}>🚀 Welcome to Fast1 Hindi News</h1>
      <p style={{ fontSize: '1.2rem', maxWidth: '600px' }}>
        This site is now live. The Admin Panel is being set up. Stay tuned for real-time news updates in Hindi!
      </p>
    </div>
  );
}
