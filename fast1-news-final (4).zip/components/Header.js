import Link from 'next/link';
import Image from 'next/image';

export default function Header() {
  return (
    <header className="bg-white shadow p-4 flex flex-col md:flex-row md:items-center md:justify-between">
      <div className="flex items-center space-x-2">
        <Image src="/logo.png" alt="Fast1 Logo" width={120} height={40} />
        <h1 className="text-2xl font-bold text-red-700 hidden md:block">Fast1</h1>
      </div>
      <nav className="mt-2 md:mt-0 space-x-4 text-sm">
        <Link href="/"><a>होम</a></Link>
        <Link href="/category/राजनीति"><a>राजनीति</a></Link>
        <Link href="/category/अपराध"><a>अपराध</a></Link>
        <Link href="/category/मनोरंजन"><a>मनोरंजन</a></Link>
        <Link href="/category/खेल"><a>खेल</a></Link>
        <Link href="/category/राष्ट्रीय"><a>राष्ट्रीय</a></Link>
        <Link href="/contact"><a>संपर्क करें</a></Link>
        <Link href="/rss.xml"><a>📡 RSS</a></Link>
        <Link href="#live"><a className="text-red-600 font-semibold">🔴 LIVE</a></Link>
      </nav>
    </header>
  );
}
